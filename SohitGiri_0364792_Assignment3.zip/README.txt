Files
home.html: Main landing page with navigation and basic content. No dynamic features.
calendar.html: A mock-up calendar showing static dates. No real-time data.
datecv.html: A CV mock-up displaying personal info. Static content only.
weather.html: Weather page with mock data (temperature, humidity, etc.). No live data fetching.

Note: Calendar, Date Convertor, and Weather are the only three pages updated for this assignment. Home page do not have any JavaScripts on it because it is only for mockup and stand out as a optional part of this assignment.